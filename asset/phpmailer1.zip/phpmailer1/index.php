
<?php
require '../../fungsi.php';

if(isset($_POST['SEND'])){

	require_once('function.php');
	
    $tgl = date('d-m-Y H:i:s');
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $alamat = $_POST["alamat"];
    $ket = $_POST["ket"];

    $to       = 'feriantotri@gmail.com';
    $subject  = 'Hubungi SSCI';
    $message  = " Nama : $nama<br>
                  Tanggal : $tgl<br>
                  Email : $email<br>
                  Alamat : $alamat<br>
                  Keterangan : $ket";
    smtp_mail($to, $subject, $message, '', '', 0, 0, 0);
    
    /*
      jika menggunakan fungsi mail biasa : mail($to, $subject, $message);
      dapat juga menggunakan fungsi smtp secara dasar : smtp_mail($to, $subject, $message);
      jangan lupa melakukan konfigurasi pada file function.php
    */
	}
?>